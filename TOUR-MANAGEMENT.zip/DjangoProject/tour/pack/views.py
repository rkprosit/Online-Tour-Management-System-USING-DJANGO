from django.shortcuts import render,redirect
from pack.models import *
# Create your views here.
def index(request):
    return render(request,'index.html')
def about(request):
    return render(request,'about.html')
def service(request):
    return render(request,'service.html')
def package1(request):
    a=package.objects.all()
    return render(request,'package.html',{'a':a})
def bookpac(request,pname):
    a=package.objects.get(pname=pname)
    return render(request,'booking.html',{'b':a})
def pacbook(request):
    b=book()
    b.pname=request.GET['pname']
    b.uname=request.GET['uname']
    b.memno=request.GET['memno']
    b.totprice=request.GET['totprice']
    b.adv=0
    b.due=request.GET['due']
    b.save()
    return redirect('../package')
def reg(request):
    return render(request,'reg.html')
def regcode(request):
    u=user()
    u.name=request.GET['name']
    u.email=request.GET['email']
    u.pwd=request.GET['pwd']
    u.phno=request.GET['phno']
    u.addr=request.GET['addr']
    u.state=request.GET['state']
    u.pin=request.GET['pin']
    u.save()
    return redirect('../index')
def logcode(request):
    email=request.GET['email']
    pwd=request.GET['pswd']
    if user.objects.filter(email=email,pwd=pwd):
        return redirect('../welcome')
    else:
        return redirect('../reg')
def welcome(request):
    return render(request,'userindex.html')
def admin(request):
    return render(request,'adminindex.html')
def addpack(request):
    return render(request,'addpack.html')
def pacadd(request):
    p=package()
    p.pname=request.GET['pname']
    p.pdesc=request.GET['pdesc']
    p.Ploc=request.GET['ploc']
    p.dloc=request.GET['dloc']
    p.price=request.GET['price']
    p.hname=request.GET['hname']
    p.save()
    return redirect('../addpack')
def viewpack(request):
    b=package.objects.all()
    return render(request,'viewpack.html',{'a':b})
def viewbook(request):
    b=book.objects.all()
    return render(request,'viewbook.html',{'a':b})