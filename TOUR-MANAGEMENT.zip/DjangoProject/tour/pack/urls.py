from django.urls import path
from . import views
urlpatterns=[
    path('',views.index),
    path('index',views.index),
    path('reg',views.reg),
    path('regcode',views.regcode),
    path('about',views.about),
    path('service',views.service),
    path('package',views.package1),
    path('logcode',views.logcode),
    path('welcome',views.welcome),
    path('bookpac/<str:pname>',views.bookpac),
    path('pacbook',views.pacbook),
    path('admin',views.admin),
    path('addpack',views.addpack),
    path('pacadd',views.pacadd),
    path('viewpack',views.viewpack),
    path('viewbook',views.viewbook),
]