from django.db import models

# Create your models here.
class user(models.Model):
    name=models.CharField(max_length=50)
    email=models.EmailField()
    pwd=models.CharField(max_length=50)
    phno=models.IntegerField()
    addr=models.CharField(max_length=50)
    state=models.CharField(max_length=50)
    pin=models.IntegerField()
    class Meta:
        db_table="user"
class package(models.Model):
    pname=models.CharField(max_length=50)
    pdesc=models.CharField(max_length=500)
    Ploc=models.CharField(max_length=50)
    dloc=models.CharField(max_length=50)
    price=models.IntegerField()
    hname=models.CharField(max_length=50)
    class Meta:
        db_table="package"
class book(models.Model):
    pname=models.CharField(max_length=50)
    uname=models.CharField(max_length=50)
    memno=models.IntegerField()
    totprice=models.IntegerField()
    adv=models.IntegerField()
    due=models.IntegerField()
    class Meta:
        db_table="book"
class hotel(models.Model):
    hname=models.CharField(max_length=50)
    email=models.EmailField()
    pwd=models.CharField(max_length=50)
    class Meta:
        db_table="hotel"